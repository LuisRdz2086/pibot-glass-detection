import os
from PIL import Image

def resize_and_pad(img, size, pad_color=0):
    h, w = img.size

    # Calculating the scaling factor to keep the aspect ratio
    scale = min(size[0] / h, size[1] / w)
    new_h, new_w = int(h * scale), int(w * scale)

    # Resize the image
    img = img.resize((new_h, new_w), Image.ANTIALIAS)

    # Create a new image with desired size and black color
    new_img = Image.new("RGB", size, pad_color)
    # Paste the resized image onto the center of new image
    new_img.paste(img, ((size[0] - new_h) // 2, (size[1] - new_w) // 2))
    return new_img

def process_images(folder_path, target_resolution):
    for filename in os.listdir(folder_path):
        if filename.endswith(".jpg"):
            img_path = os.path.join(folder_path, filename)
            img = Image.open(img_path)
            img = resize_and_pad(img, target_resolution)
            img.save(os.path.join(folder_path, "processed_" + filename))

# Use the function
folder_path = "/mnt/d/Glass_Detection/Mirror-Glass-Detection/CVPR2020_GDNet/GDD/test/image"
target_resolution = (1280, 1024)  # Change to desired resolution
process_images(folder_path, target_resolution)
