import os

def rename_png_files(folder_path):
    for filename in os.listdir(folder_path):
        if filename.endswith(".png"):
            new_filename = filename.replace(".png", "_gdnet.png")
            os.rename(os.path.join(folder_path, filename), os.path.join(folder_path, new_filename))
    print("Renaming PNG files complete.")

# Uso:
folder_path = "/mnt/d/Glass_Detection/Mirror-Glass-Detection/CVPR2020_GDNet/results/GDD/GDNet_200"
rename_png_files(folder_path)
