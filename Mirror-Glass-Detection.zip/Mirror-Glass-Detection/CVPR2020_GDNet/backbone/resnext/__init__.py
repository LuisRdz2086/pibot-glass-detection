from .resnext101_regular import ResNeXt101
