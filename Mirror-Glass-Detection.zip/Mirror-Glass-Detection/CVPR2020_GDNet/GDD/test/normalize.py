import os
from PIL import Image

def crop_to_aspect_ratio(directory, output_directory, aspect_ratio=(1280, 1024)):
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    for img_filename in os.listdir(directory):
        if img_filename.endswith('.jpg'):
            img_path = os.path.join(directory, img_filename)
            img = Image.open(img_path)

            # Calcular la nueva dimensión para mantener la relación de aspecto
            img_aspect = img.width / img.height
            target_aspect = aspect_ratio[0] / aspect_ratio[1]

            if img_aspect > target_aspect:
                # La imagen es demasiado ancha, recortar los lados
                new_width = int(target_aspect * img.height)
                left = (img.width - new_width) / 2
                img_cropped = img.crop((left, 0, left + new_width, img.height))
            else:
                # La imagen es demasiado alta, recortar la parte superior e inferior
                new_height = int(img.width / target_aspect)
                top = (img.height - new_height) / 2
                img_cropped = img.crop((0, top, img.width, top + new_height))

            # Guardar la imagen recortada
            img_cropped.save(os.path.join(output_directory, img_filename))

# Especificar directorio del dataset y directorio de salida
dataset_directory = '/mnt/d/Glass_Detection/Mirror-Glass-Detection/CVPR2020_GDNet/GDD/test/image'
output_directory = '/mnt/d/Glass_Detection/Mirror-Glass-Detection/CVPR2020_GDNet/GDD/test/cutted'

crop_to_aspect_ratio(dataset_directory, output_directory)
