Glass Detection datesets & references:

[1] Glass Identification-Multiclass Classification

https://www.kaggle.com/venkatkrishnan/glass-identification-multiclass-problem

[2] Glass Identification Data Set

https://code.datasciencedojo.com/datasciencedojo/datasets/tree/master/Glass%20Identification

[3] UCI-glass-detection

https://github.com/aaqibqadeer/UCI-glass-detection/blob/master/Solution/Solution.ipynb

[4] Mirror and Glass Detection/Segmentation

https://www.cs.cityu.edu.hk/~rynson/projects/mirror_glass/MirrorGlassDetection.html

