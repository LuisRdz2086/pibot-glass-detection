"""Base segmentation dataset"""
import os
import random
import numpy as np
import torchvision

from PIL import Image, ImageOps, ImageFilter
from ...config import cfg

__all__ = ['SegmentationDataset']


class SegmentationDataset(object):
    """Segmentation Base Dataset"""

    def __init__(self, root, split, mode, transform, base_size=520, crop_size=480):
        super(SegmentationDataset, self).__init__()
        self.root = os.path.join(cfg.ROOT_PATH, root)
        self.split = split
        self.mode = mode if mode is not None else split
        if(self.mode == 'val' or self.mode == "test"):
            self.transform = transform 
        self.base_size = base_size
        self.crop_size = self.to_tuple(crop_size)
        self.color_jitter = self._get_color_jitter()

    def to_tuple(self, size):
        if isinstance(size, (list, tuple)):
            return tuple(size)
        elif isinstance(size, (int, float)):
            return tuple((size, size))
        else:
            raise ValueError('Unsupport datatype: {}'.format(type(size)))

    def _get_color_jitter(self):
        color_jitter = cfg.AUG.COLOR_JITTER
        if color_jitter is None:
            return None
        if isinstance(color_jitter, (list, tuple)):
            # color jitter should be a 3-tuple/list if spec brightness/contrast/saturation
            # or 4 if also augmenting hue
            assert len(color_jitter) in (3, 4)
        else:
            # if it's a scalar, duplicate for brightness, contrast, and saturation, no hue
            color_jitter = (float(color_jitter),) * 3
        return torchvision.transforms.ColorJitter(*color_jitter)

    def _val_sync_transform(self, img, mask):
        short_size = self.base_size
        img = img.resize((short_size, short_size), Image.BILINEAR)
        mask = mask.resize((short_size, short_size), Image.NEAREST)

        # final transform
        img, mask = self._img_transform(img), self._mask_transform(mask)
        return img, mask

    def _sync_transform(self, img, mask):
        short_size = self.base_size
        img = img.resize((short_size, short_size), Image.BILINEAR)
        mask = mask.resize((short_size, short_size), Image.NEAREST)
        img = np.array(img)
        mask = np.array(mask).astype('int32')
           
        if np.random.random() < cfg.AUG.FLIP_PROB:
            img = img[:, ::-1, :]
            mask = mask[:, ::-1]  

        if cfg.AUG.ROTATE is True:
            rotate_count = np.random.randint(0,3)
            img = np.rot90(img,k=rotate_count,axes=(0,1))
            mask = np.rot90(mask,k=rotate_count,axes=(0,1))
        
        # final transform
        img, mask = self._img_transform(img), self._mask_transform(mask)
        return img, mask

    def _img_transform(self, img):
        return np.array(img)

    def _mask_transform(self, mask):
        return np.array(mask).astype('int32')

    @property
    def num_class(self):
        """Number of categories."""
        return self.NUM_CLASS

    @property
    def pred_offset(self):
        return 0
