### EVALUATE on MSD, GLASS and CAMOUFLAGE DATASETS
1. using 'predict.py' to generate the predicted results
2. using 'evaluate.ipynb' (for MSD and GLASS) and 'camouflage_evaluate/main.m' (for CAMOUFLAGE) to evaluate the predicted results
