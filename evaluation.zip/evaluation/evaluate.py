import cv2
import numpy as np
import os
import glob
import csv

def calculate_iou(mask_true, mask_pred):
    intersection = np.logical_and(mask_true, mask_pred)
    union = np.logical_or(mask_true, mask_pred)
    iou = np.sum(intersection) / np.sum(union)
    return iou

def calculate_pixel_accuracy(mask_true, mask_pred):
    correct = np.sum(mask_true == mask_pred)
    total = mask_true.size
    return correct / total

def calculate_mae(mask_true, mask_pred):
    return np.mean(np.abs(mask_true - mask_pred))

def process_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise FileNotFoundError(f"Unable to find or open the image {image_path}")
    _, binary_mask = cv2.threshold(image, 1, 255, cv2.THRESH_BINARY)
    return binary_mask / 255


def main():
    approaches = ['implicit', 'fanet', 'gdnet']
    metrics = {'iou': [], 'pixel_acc': [], 'mae': []}
    results = {approach: {metric: [] for metric in metrics} for approach in approaches}
    csv_files = {approach: open(f'{approach}_metrics.csv', 'w', newline='') for approach in approaches}
    csv_writers = {approach: csv.writer(csv_file) for approach, csv_file in csv_files.items()}
    
    # Write headers for CSV files
    for writer in csv_writers.values():
        writer.writerow(['Image Name', 'IoU', 'Pixel Accuracy', 'MAE'])

    mask_files = glob.glob('mask/*.png')
    for mask_file in mask_files:
        mask_true = process_image(mask_file)
        # Define 'image_name' outside the 'approaches' loop, so it's accessible when writing to CSV
        image_name = os.path.basename(mask_file).replace('-mask.png', '')

        for approach in approaches:
            inferred_file_name = image_name + f'_{approach}.png'
            inferred_mask_file = os.path.join(approach, inferred_file_name)
            mask_pred = process_image(inferred_mask_file)

            iou = calculate_iou(mask_true, mask_pred)
            pixel_acc = calculate_pixel_accuracy(mask_true, mask_pred)
            mae = calculate_mae(mask_true, mask_pred)

            results[approach]['iou'].append(iou)
            results[approach]['pixel_acc'].append(pixel_acc)
            results[approach]['mae'].append(mae)

            # Write individual image metrics to CSV
            csv_writers[approach].writerow([image_name, iou, pixel_acc, mae])

    # Close CSV files
    for csv_file in csv_files.values():
        csv_file.close()

    for approach in approaches:
        print(f"Results for {approach}:")
        for metric in metrics:
            avg_metric = np.mean(results[approach][metric])
            print(f"Average {metric}: {avg_metric:.4f}")

if __name__ == "__main__":
    main()
